import { FastifyInstance } from 'fastify'
import { taskQueue } from '../services/queue'

/**
 * API routes for scheduling tasks on repositories.  Tasks are processed
 * asynchronously by the workers defined in services/queue.ts.  Clients
 * can trigger tasks for summarization, diff explanation, etc.
 */
export async function taskRoutes(app: FastifyInstance) {
  // Trigger a repo summary generation
  app.post('/repos/:owner/:repo/tasks/summary', async (request) => {
    const { owner, repo } = request.params as any
    await taskQueue.add('repo_summary', { owner, repo })
    return { status: 'scheduled' }
  })

  // Return a list of current tasks in the queue (for demo purposes)
  app.get('/tasks', async () => {
    const jobs = await taskQueue.getJobs(['waiting', 'active', 'completed', 'failed', 'delayed'])
    const results = [] as any[]
    for (const job of jobs) {
      const state = await job.getState()
      results.push({ id: String(job.id), name: job.name, status: state })
    }
    return results
  })
}