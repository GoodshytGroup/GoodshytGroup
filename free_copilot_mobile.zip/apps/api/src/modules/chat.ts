import { FastifyInstance } from 'fastify'
import fetch from 'node-fetch'

/**
 * Chat routes for interacting with the LLM via OpenRouter.  These endpoints
 * currently proxy requests to OpenRouter with a simple system prompt and
 * return the raw response.  The response format is plain text.  For
 * structured tasks (planning, execution) refer to the planner/executor modules.
 */
export async function chatRoutes(app: FastifyInstance) {
  app.post('/chat/repo', async (request) => {
    const body = request.body as any
    const prompt: string = body?.prompt || ''
    const res = await fetch('https://openrouter.ai/api/v1/chat/completions', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${process.env.OPENROUTER_API_KEY}`,
        'Content-Type': 'application/json',
        'HTTP-Referer': 'https://example.com',
        'X-OpenRouter-Title': 'Free Copilot API'
      },
      body: JSON.stringify({
        model: 'deepseek/deepseek-chat-v3-0324:free',
        messages: [
          { role: 'system', content: 'You are a helpful repository assistant.' },
          { role: 'user', content: prompt }
        ]
      })
    })
    const data = await res.json()
    return data
  })
}