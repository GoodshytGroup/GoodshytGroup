import { FastifyInstance } from 'fastify'
import { ingestRepo } from '../services/ingest'

/**
 * API routes for ingesting repositories.  This module exposes a POST endpoint
 * that triggers ingestion for a given owner/repo.  Ingestion will fetch
 * repository contents and persist a lightweight index for later retrieval.
 */
export async function ingestRoutes(app: FastifyInstance) {
  app.post('/repos/:owner/:repo/ingest', async (request) => {
    const { owner, repo } = request.params as any
    const token = process.env.GITHUB_TOKEN
    if (!token) return { error: 'Missing GitHub token' }
    const files = await ingestRepo(owner, repo, token)
    return { filesCount: files.length }
  })
}