import { FastifyInstance } from 'fastify'
import fetch from 'node-fetch'

/**
 * Routes for GitHub OAuth and listing user repositories.  The client
 * must supply valid GitHub OAuth client ID/secret and personal access token
 * through environment variables.  Only read operations are implemented here.
 */
export async function githubRoutes(app: FastifyInstance) {
  // Start OAuth login by redirecting the user to GitHub
  app.get('/auth/github/start', async (_, reply) => {
    const clientId = process.env.GITHUB_CLIENT_ID
    if (!clientId) {
      return reply.status(500).send({ error: 'Missing GITHUB_CLIENT_ID' })
    }
    const url = `https://github.com/login/oauth/authorize?client_id=${clientId}`
    reply.redirect(url)
  })

  // OAuth callback: exchange code for access token
  app.get('/auth/github/callback', async (request, reply) => {
    const code = (request.query as any).code
    const clientId = process.env.GITHUB_CLIENT_ID
    const clientSecret = process.env.GITHUB_CLIENT_SECRET
    if (!code || !clientId || !clientSecret) {
      return reply.status(400).send({ error: 'Invalid OAuth callback' })
    }
    const res = await fetch('https://github.com/login/oauth/access_token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
      body: JSON.stringify({
        client_id: clientId,
        client_secret: clientSecret,
        code
      })
    })
    const data = await res.json() as any
    // In a real implementation you would store the access token and associate it
    // with the authenticated user.  Here we simply return it.
    return { token: data.access_token }
  })

  // List repositories for the user; uses the personal access token in .env
  app.get('/repos', async () => {
    const token = process.env.GITHUB_TOKEN
    if (!token) return []
    const res = await fetch('https://api.github.com/user/repos', {
      headers: { Authorization: `Bearer ${token}`, 'Accept': 'application/vnd.github+json' }
    })
    return res.json()
  })
}