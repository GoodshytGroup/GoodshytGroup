import { FastifyInstance } from 'fastify'
import { taskQueue } from '../services/queue'

/**
 * GitHub webhook handler.  This endpoint receives events from GitHub and
 * triggers appropriate tasks such as reindexing or generating summaries.
 */
export async function webhookRoutes(app: FastifyInstance) {
  app.post('/webhooks/github', async (request) => {
    const event = request.headers['x-github-event'] as string
    const payload = request.body as any
    if (event === 'push') {
      // schedule a reindex task
      await taskQueue.add('reindex', { owner: payload.repository.owner.login, repo: payload.repository.name })
    }
    if (event === 'pull_request') {
      // schedule a summary generation
      await taskQueue.add('pr_summary', { owner: payload.repository.owner.login, repo: payload.repository.name, pr: payload.number })
    }
    return { received: true }
  })
}