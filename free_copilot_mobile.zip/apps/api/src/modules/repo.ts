import { FastifyInstance } from 'fastify'
import { ingestRepo } from '../services/ingest'

/**
 * Routes for repository operations: listing files and retrieving file content.
 */
export async function repoRoutes(app: FastifyInstance) {
  // List files for a repository (root level only)
  app.get('/repos/:owner/:repo/files', async (request) => {
    const { owner, repo } = request.params as any
    const token = process.env.GITHUB_TOKEN
    if (!token) return []
    const files = await ingestRepo(owner, repo, token)
    // Only return path and type to minimize payload
    return files.map((f) => ({ path: f.path, type: f.type }))
  })

  // Retrieve the contents of a single file (text files only)
  app.get('/repos/:owner/:repo/file', async (request, reply) => {
    const { owner, repo } = request.params as any
    const filePath = (request.query as any).path
    const token = process.env.GITHUB_TOKEN
    if (!token || !filePath) return reply.status(400).send({ error: 'Missing parameters' })
    const res = await fetch(`https://api.github.com/repos/${owner}/${repo}/contents/${filePath}`, {
      headers: { Authorization: `Bearer ${token}`, 'Accept': 'application/vnd.github.raw' }
    })
    if (!res.ok) return reply.status(res.status).send(await res.text())
    const text = await res.text()
    return { content: text }
  })
}