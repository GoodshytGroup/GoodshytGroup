/**
 * The planner converts a high level prompt into a sequence of steps.  In a
 * future version this could call an LLM via OpenRouter to generate the plan
 * automatically.  For now, return a fixed example plan.
 */
export async function planTask(prompt: string): Promise<string[]> {
  // TODO: integrate LLM planning
  return [
    'fetch relevant files',
    'analyze structure',
    'generate output',
    'return structured result'
  ]
}