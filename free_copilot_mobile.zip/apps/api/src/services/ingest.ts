import fetch from 'node-fetch'

/**
 * Fetch the repository contents from GitHub.  Returns an array of
 * file metadata objects.  Only supports reading at the root level; for
 * large repos you should paginate or use Git trees API instead.
 */
export async function ingestRepo(owner: string, repo: string, token: string) {
  const res = await fetch(`https://api.github.com/repos/${owner}/${repo}/contents`, {
    headers: {
      Authorization: `Bearer ${token}`,
      'Accept': 'application/vnd.github+json'
    }
  })
  const files = await res.json() as Array<{ path: string; type: string }>
  // Here you could persist the files to a database or index; this example simply returns them
  return files
}