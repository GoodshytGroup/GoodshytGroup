/**
 * Indexing service.  Extracts high‑signal files and optionally creates a
 * semantic index using embeddings.  This stub simply selects JavaScript and
 * TypeScript files.
 */
export function buildIndex(files: Array<{ path: string; type: string }>) {
  return files.filter((f) => /\.(js|ts|jsx|tsx)$/.test(f.path))
}