import { Queue, Worker } from 'bullmq'
import { ingestRepo } from './ingest'
import { planTask } from './planner'
import { executePlan } from './executor'
import { createPullRequest } from './githubWrite'

// In-memory Redis URL is fine for local development; override via REDIS_URL
const connection = { host: '127.0.0.1', port: 6379 }

export const taskQueue = new Queue('tasks', { connection })

// Worker that processes tasks.  In a real app you might run this in a separate process.
new Worker('tasks', async (job) => {
  const { name, data } = job
  console.log(`Processing ${name}`, data)
  if (name === 'repo_summary') {
    const files = await ingestRepo(data.owner, data.repo, process.env.GITHUB_TOKEN || '')
    // Generate a plan using the planner
    const plan = await planTask(`Summarize repository ${data.owner}/${data.repo}`)
    // For demonstration, we do not generate actual summary but we could call OpenRouter here
    console.log('Generated plan:', plan)
  } else if (name === 'reindex') {
    await ingestRepo(data.owner, data.repo, process.env.GITHUB_TOKEN || '')
  } else if (name === 'pr_summary') {
    // Generate PR summary using LLM (not implemented here)
    console.log('Generate PR summary for PR', data.pr)
  }
  return {}
}, { connection })