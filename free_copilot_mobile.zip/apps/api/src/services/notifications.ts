import { FastifyInstance } from 'fastify'

/**
 * Notification service stub.  In a real app this would push messages to
 * connected clients via websockets, push notifications or email.  Here
 * it simply logs notifications to the console.
 */
export function notifyUser(userId: string, message: string) {
  console.log(`Notify ${userId}:`, message)
}