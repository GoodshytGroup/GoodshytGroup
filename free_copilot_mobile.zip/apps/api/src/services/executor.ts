import { planTask } from './planner'

/**
 * Execute a plan one step at a time.  In the future this will call specific
 * functions for each action (file read/write, branch creation, PR open, etc.).
 */
export async function executePlan(plan: string[]) {
  for (const step of plan) {
    console.log('Executing:', step)
    // Placeholder: in a real implementation, call appropriate service
    await new Promise((resolve) => setTimeout(resolve, 100))
  }
}