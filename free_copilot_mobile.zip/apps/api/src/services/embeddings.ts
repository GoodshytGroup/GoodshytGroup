/**
 * Embeddings service stub.  A real implementation would call an embedding
 * provider to generate vector representations of file contents and store them
 * in a vector database.  This stub returns an empty index.
 */
export async function generateEmbeddingsForFiles(_files: Array<{ path: string; content: string }>) {
  return {}
}