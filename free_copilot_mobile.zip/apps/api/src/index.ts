import Fastify from 'fastify'
import dotenv from 'dotenv'

import { githubRoutes } from './modules/github'
import { chatRoutes } from './modules/chat'
import { ingestRoutes } from './modules/ingest'
import { repoRoutes } from './modules/repo'
import { webhookRoutes } from './modules/webhooks'
import { taskRoutes } from './modules/tasks'

dotenv.config()

const app = Fastify({ logger: true })

// Register modules
app.register(githubRoutes)
app.register(chatRoutes)
app.register(ingestRoutes)
app.register(repoRoutes)
app.register(webhookRoutes)
app.register(taskRoutes)

app.listen({ port: 3000 }, () => {
  console.log('API running on http://localhost:3000')
})