import { View, Text, Button } from 'react-native'
import { useRouter } from 'expo-router'

export default function Home() {
  const router = useRouter()

  return (
    <View style={{ padding: 20 }}>
      <Text style={{ fontSize: 24, fontWeight: 'bold', marginBottom: 16 }}>Free Copilot</Text>
      <Text style={{ marginBottom: 12 }}>
        Connect your GitHub account to start exploring your repositories, ask questions, and generate pull requests.
      </Text>
      <Button title="Connect GitHub" onPress={() => router.push('/auth')} />
    </View>
  )
}