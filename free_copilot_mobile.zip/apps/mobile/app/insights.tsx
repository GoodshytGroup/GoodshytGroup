import { View, Text } from 'react-native'

export default function Insights() {
  return (
    <View style={{ flex: 1, padding: 20 }}>
      <Text style={{ fontSize: 20, fontWeight: 'bold', marginBottom: 16 }}>Repo Insights</Text>
      <Text>Insights dashboard is not yet implemented.</Text>
    </View>
  )
}