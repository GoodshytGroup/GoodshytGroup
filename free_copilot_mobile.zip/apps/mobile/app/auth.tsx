import { useEffect } from 'react'
import { Linking } from 'react-native'
import { useRouter } from 'expo-router'

/**
 * This screen initiates the GitHub OAuth flow.  When the component mounts it opens
 * the API endpoint to start authentication.  Once the auth completes, GitHub
 * redirects back to the API server which should send the user back to the app.
 */
export default function Auth() {
  const router = useRouter()

  useEffect(() => {
    Linking.openURL('http://localhost:3000/auth/github/start')
    // redirect to repo list after a short delay; in production you would listen
    // for a deep link callback instead of using a timeout.
    setTimeout(() => {
      router.push('/repos')
    }, 2000)
  }, [])

  return null
}