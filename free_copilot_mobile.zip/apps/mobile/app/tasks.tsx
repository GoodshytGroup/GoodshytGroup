import { useEffect, useState } from 'react'
import { View, Text, FlatList } from 'react-native'

interface Task {
  id: string
  name: string
  status: string
}

export default function Tasks() {
  const [tasks, setTasks] = useState<Task[]>([])

  useEffect(() => {
    async function fetchTasks() {
      try {
        const res = await fetch('http://localhost:3000/tasks')
        const data = await res.json()
        setTasks(data)
      } catch (err) {
        console.error('Failed to fetch tasks', err)
      }
    }
    fetchTasks()
  }, [])

  return (
    <View style={{ flex: 1, padding: 20 }}>
      <Text style={{ fontSize: 20, fontWeight: 'bold', marginBottom: 16 }}>Task Center</Text>
      <FlatList
        data={tasks}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={{ paddingVertical: 12, borderBottomWidth: 1, borderColor: '#eee' }}>
            <Text style={{ fontWeight: 'bold' }}>{item.name}</Text>
            <Text>Status: {item.status}</Text>
          </View>
        )}
      />
    </View>
  )
}