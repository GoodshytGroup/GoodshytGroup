import { useEffect, useState } from 'react'
import { View, Text, ScrollView, Pressable } from 'react-native'
import { useLocalSearchParams, useRouter } from 'expo-router'

interface FileMeta {
  path: string
  type: string
}

export default function Repo() {
  const { owner, repo } = useLocalSearchParams<{ owner: string; repo: string }>()
  const [files, setFiles] = useState<FileMeta[]>([])
  const router = useRouter()

  useEffect(() => {
    async function fetchFiles() {
      try {
        const res = await fetch(`http://localhost:3000/repos/${owner}/${repo}/files`)
        const data = await res.json()
        setFiles(data)
      } catch (err) {
        console.error('Failed to fetch files', err)
      }
    }
    if (owner && repo) {
      fetchFiles()
    }
  }, [owner, repo])

  return (
    <ScrollView contentContainerStyle={{ padding: 20 }}>
      <Text style={{ fontSize: 20, fontWeight: 'bold', marginBottom: 16 }}>{owner}/{repo}</Text>
      <Pressable
        onPress={async () => {
          // Trigger summarization task
          await fetch(`http://localhost:3000/repos/${owner}/${repo}/tasks/summary`, { method: 'POST' })
          alert('Summary task started – check notifications')
        }}
        style={{ marginBottom: 20 }}
      >
        <Text style={{ color: 'blue' }}>Generate Repo Summary</Text>
      </Pressable>
      {files.map((file) => (
        <View key={file.path} style={{ marginBottom: 8 }}>
          <Text>{file.path}</Text>
        </View>
      ))}
    </ScrollView>
  )
}