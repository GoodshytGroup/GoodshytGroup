import { useEffect, useState } from 'react'
import { View, Text, FlatList } from 'react-native'

interface Draft {
  id: number
  title: string
  body: string
}

export default function PRDrafts() {
  const [drafts, setDrafts] = useState<Draft[]>([])

  useEffect(() => {
    async function fetchDrafts() {
      // Placeholder: would call API to fetch pending PR drafts
      setDrafts([])
    }
    fetchDrafts()
  }, [])

  return (
    <View style={{ flex: 1, padding: 20 }}>
      <Text style={{ fontSize: 20, fontWeight: 'bold', marginBottom: 16 }}>PR Drafts</Text>
      {drafts.length === 0 ? (
        <Text>No drafts yet.</Text>
      ) : (
        <FlatList
          data={drafts}
          keyExtractor={(item) => String(item.id)}
          renderItem={({ item }) => (
            <View style={{ paddingVertical: 12, borderBottomWidth: 1, borderColor: '#eee' }}>
              <Text style={{ fontWeight: 'bold' }}>{item.title}</Text>
              <Text numberOfLines={2}>{item.body}</Text>
            </View>
          )}
        />
      )}
    </View>
  )
}