import { useEffect, useState } from 'react'
import { View, Text, FlatList, Pressable } from 'react-native'
import { useRouter } from 'expo-router'

interface Repo {
  id: number
  name: string
  full_name: string
}

export default function Repos() {
  const [repos, setRepos] = useState<Repo[]>([])
  const router = useRouter()

  useEffect(() => {
    async function fetchRepos() {
      try {
        const res = await fetch('http://localhost:3000/repos')
        const data = await res.json()
        setRepos(data)
      } catch (err) {
        console.error('Failed to fetch repos', err)
      }
    }
    fetchRepos()
  }, [])

  return (
    <View style={{ flex: 1, padding: 20 }}>
      <Text style={{ fontSize: 20, fontWeight: 'bold', marginBottom: 16 }}>Select a Repository</Text>
      <FlatList
        data={repos}
        keyExtractor={(item) => String(item.id)}
        renderItem={({ item }) => (
          <Pressable
            onPress={() => router.push({ pathname: '/repo', params: { owner: item.full_name.split('/')[0], repo: item.name } })}
            style={{ paddingVertical: 12, borderBottomWidth: 1, borderColor: '#ddd' }}
          >
            <Text style={{ fontSize: 16 }}>{item.full_name}</Text>
          </Pressable>
        )}
      />
    </View>
  )
}