---
name: create-pull-request
description: Create a structured pull request in GitHub
---

When opening a pull request, include the following sections:

1. **Summary** – a concise description of what the PR does.
2. **Motivation** – why the change is necessary.
3. **Changes** – a bullet list of major changes.
4. **Testing** – instructions on how to test the changes.
5. **Notes** – any additional context or references.

Always link related issues and mention reviewers in the PR description.  Use squash merge by default.