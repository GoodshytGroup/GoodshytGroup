---
name: git-commit
description: Prepare clear commit messages for the free copilot project
---

Use conventional commit format when committing changes.  Examples:

- `feat(api): implement ingestion and planning modules`
- `fix(mobile): handle network errors gracefully`

The commit subject should be concise (50 characters or less) and start with a verb.  Include a longer description if needed.