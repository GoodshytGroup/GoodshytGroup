---
name: build-test-verify
description: Run build, lint and test commands before committing or opening a PR
---

Run the following commands to verify the project state:

```bash
cd apps/api && npm install && npm test
cd ../../apps/mobile && npm install && npm test
```

Ensure there are no lint errors, tests pass and the app compiles before proceeding to commit or open a pull request.