---
name: self-review-checklist
description: Checklist for reviewing changes before committing or opening a PR
---

1. Have you run lint and tests?  Make sure `npm test` passes for both API and mobile.
2. Are all new files added and no secrets committed?  Check `.env` and other sensitive files.
3. Is the commit message clear and conventional?  Follow the guidelines in `git-commit` skill.
4. Are documentation files updated if behaviour changed?  Update `README.md` and docs as necessary.
5. Does the code follow the project’s architecture and conventions?  Keep modules organised under `src/modules`.