# Free Copilot Mobile App with Autonomous PR Agent

This project is an extended version of the free copilot mobile scaffold.  It implements a **production‑ready agent system** that can ingest GitHub repositories, reason about their contents and optionally write back to GitHub.  The goal is to provide Copilot‑like assistance for developers on the go while keeping full control over modifications (Plan → Approve → Execute).

## Overview

The repository contains two main apps and a shared package:

* `apps/mobile` – A React Native Expo application for the mobile interface.  It lets users connect to GitHub, select repos, view code, interact with the AI assistant, manage tasks and review pull requests.
* `apps/api` – A Node/TypeScript backend built with Fastify.  It exposes REST endpoints for authentication, repository ingestion, planning, execution and notifications.  It also integrates with OpenRouter for LLM calls and the GitHub API for reading and writing repository data.
* `packages/shared` – Shared types and utilities used across the mobile and API codebases.

## Agent Pipeline

The system follows a multi‑stage pipeline to process user requests:

1. **Ingest** – fetches repository contents from GitHub and persists a lightweight index.
2. **Index** – extracts high‑signal files and optionally stores semantic embeddings for retrieval.
3. **Reason** – calls OpenRouter to generate a high‑level plan from the user’s prompt.
4. **Plan** – converts the high‑level plan into executable steps and actions.
5. **Execute** – runs each step, optionally editing files, creating branches and generating PRs.  Execution stops at approval gates to ensure human oversight.
6. **Verify** – runs CI, lint and tests to ensure changes are correct.
7. **Notify** – updates the mobile client with task status and results.

## Running locally

Before running either app you will need a `.env` file at the root with the following keys:

```
GITHUB_CLIENT_ID=your_github_oauth_client_id
GITHUB_CLIENT_SECRET=your_github_oauth_client_secret
GITHUB_TOKEN=personal_access_token_with_repo_scope
OPENROUTER_API_KEY=your_openrouter_api_key
```

Install dependencies and start the API server:

```bash
cd apps/api
npm install
npm run dev
```

Start the mobile app using Expo:

```bash
cd apps/mobile
npm install
npx expo start
```

## Next steps

This scaffold provides the foundation for an autonomous PR agent.  You can extend the modules under `apps/api/src/modules` to implement real indexing, embeddings and code editing using the GitHub API.  The mobile app can be expanded with screens for task management, PR review and notifications.
