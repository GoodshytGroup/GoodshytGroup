# Free Copilot Mobile Agent Guide

## Purpose

This repository implements a mobile AI assistant and backend that collaborate to ingest and understand GitHub repositories and, when authorised, propose code changes via pull requests.  The goal is to give developers a powerful copilot that can analyse projects, suggest improvements and automate routine tasks from a phone.

## Structure

- `apps/mobile` – Expo React Native app for iOS/Android.  Handles authentication, repository selection, tasks, PR review and notifications.
- `apps/api` – Fastify API in TypeScript.  Exposes endpoints for GitHub OAuth, repository ingestion, planning, execution, tasks and webhooks.
- `packages/shared` – Shared types and utilities.
- `.github/workflows` – GitHub Actions CI configuration.

## How to operate this agent

1. **Ingest a repo** – When a user selects a repository, call the ingestion endpoint (`POST /repos/:owner/:repo/ingest`).  This fetches the repository contents and builds a lightweight index.
2. **Plan** – Convert the user’s request into a step‑by‑step plan.  Use `services/planner.ts` or call the LLM via OpenRouter.  Plans should outline reading files, analysing structure, generating output and proposing changes.
3. **Approval** – Before making any write operations (creating branches, committing changes, opening pull requests), ensure the user has approved the plan.  The UI should present the plan and await confirmation.
4. **Execute** – Execute each step of the plan sequentially.  Use `services/executor.ts` to iterate through steps and call into GitHub or LLM services as required.  File edits and commit creation should be implemented in `services/githubWrite.ts`.
5. **Open a PR** – After edits have been made and tests pass, call `createPullRequest` from `services/githubWrite.ts` to open a pull request on the user’s behalf.
6. **Notify** – Send task updates and results back to the mobile app via `services/notifications.ts`.

## Progressive disclosure

This root guide provides high‑level rules.  Detailed operational guidance lives in:

- `.claude/skills/` – task‑specific playbooks (e.g. commit etiquette, CI guidelines).
- `docs/agent-guides/` – deeper reference docs on architecture, pipeline, and design patterns.

Keep this file concise.  Deep content belongs in the appropriate skill or guide files.